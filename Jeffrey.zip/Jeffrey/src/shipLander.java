import apcs.Window;

public class shipLander {

	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		
		start();
	}
	public static void start() {
		int width = 800;
		int height = 900;
		int x = 100;
		int y = 100;
		int ys = 0;
		int xs = 0;
		int level = 1;
		String message = "Land the rocket on the landing pad without too much force. Level 1";
		boolean lose = false;
		boolean win = false;
		Window.size(width, height);

		int landx = Window.random(1, width);
		while (true) {
			Window.frame();
			Window.out.background("light blue");
			Window.out.color("black");
			Window.out.rectangle(x, y, 40, 60);
			Window.out.print(message, 20, 20);
			if (Window.key.pressed("up")) {
				Window.out.color("orange");
				Window.out.polygon(x - 20, y + 30, x + 20, y + 30, x, y + 50);
				ys -= 2;
			}
			Window.out.color("black");
			Window.out.rectangle(landx, height, 100, 20);
			ys += 1;
			y += ys;

			if (Window.key.pressed("right")) {
				x += 2;

			}
			if (Window.key.pressed("left")) {
				x -= 2;

			}

			if (y >= height - 30) {
				if (Math.abs(x - landx) < 50 && ys < 10 - level) {
					x = 100;
					y = 100;
					ys = 0;
					level += 1;
					message = "Good landing! Now on level " + level;
					
					if (level > 9 ) {
						level = 9;
								message = "You beat the last level. Replay level 9";
					}
					landx = Window.random(1, width);
				} else {
					x = 100;
					y = 100;
					ys = 0;
					message = "You lose! Try again. Still on level " + level;
					landx = Window.random(1, width);
				}

			}

		}
	}
}
