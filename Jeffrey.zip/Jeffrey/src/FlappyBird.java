import apcs.Window;


public class FlappyBird {

    public static void main(String[] args) {
        // Set up the window
        Window.size(400, 600);
        Window.setFrameRate(30);

        // Variables and initial values
        int x = 200;
        int y = 300;
        int speed = 0;

        // The x position of the pipe
        int pipe1x = 425;
        int pipe2x = 650;
        
        // Where the space should be in this pipe
        int gap1 = 100 + Window.rollDice(400);
        int gap2 = 100 + Window.rollDice(400);

        // Infinitely draw frames of the animation
        while (true) {
            // Draw the scene
            Window.out.background("light blue");

            // Draw the bird
            Window.out.color("yellow");
            Window.out.oval(x, y, 20, 15);

            // Draw a pipe at the pipe's x position
            Window.out.color("green");
            // Top pipes
            Window.out.rectangle(pipe1x, (gap1 - 50) / 2, 50, gap1 - 50);
            Window.out.rectangle(pipe2x, (gap2 - 50) / 2, 50, gap2 - 50);
            // Bottom pipes
            Window.out.rectangle(pipe1x, 325 + gap1 / 2, 50, 550 - gap1);
            Window.out.rectangle(pipe2x, 325 + gap2 / 2, 50, 550 - gap2);
            
            // Move the bird
            y = y + speed;
            speed = speed + 1;
            
            if (y > 600) {
                y = 300;
                speed = 0;
                pipe1x = 425;
                pipe2x = 650;
            }
            
            // If I'm colliding with the pipe, then reset all variables
            if (x >= pipe1x - 35 && x <= pipe1x + 35 && y >= 0 && y <= gap1 - 50) {
                y = 300;
                speed = 0;
                pipe1x = 425;
                pipe2x = 650;
            }
            if (x >= pipe1x + 35 && x <= pipe1x - 35 && y <= gap1 + 50) {
                y = 300;
                speed = 0;
                pipe1x = 425;
                pipe2x = 650;
            }
            
            // if the space key is pressed
            if ( Window.key.pressed ( "space" ) ) {
                speed = -10;
            }

            // Move the pipe
            pipe1x = pipe1x - 3;
            pipe2x = pipe2x - 3;

            // if the pipe is off the screen to the left
            if (pipe1x <= -25) {
                // put it back on the right side
                pipe1x = 425;
                gap1 = 100 + Window.rollDice(400);
            }
            if (pipe2x <= -25) {
                pipe2x = 425;
                gap2 = 100 + Window.rollDice(400);
            }
            
            

            Window.frame();
        }

    }

}
