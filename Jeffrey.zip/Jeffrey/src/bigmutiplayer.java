

import apcs.Window;

public class bigmutiplayer {

    public static void main(String[] args) {
        
        // Connect to this location
        Window.mesh.join("104.236.128.169");
        
        String me = "jeffrey";
        
        // Save an integer value for everyone
        int keshavx = 0;
        int keshavy = 0;
        int andrewx = 0;
        int andrewy = 0;
        int alexx = 0;
        int alexy = 0;
        int joshx = 0;
        int joshy = 0;
        int aryanx = 0;
        int aryany = 0;
        int jeffreyx = 0;
        int jeffreyy = 0;
        int nikhilx = 0;
        int nikhily = 0;
        int anikax = 0;
        int anikay = 0;
        int ishirx = 0;
        int ishiry = 0;
        int nirekx = 0;
        int nireky = 0;
        
        // One time set the background to white
        Window.out.background("white");
        
        // Infinitely repeat the code in this block
        while (1 < 2) {
            // Tell everyone about my x and y position
            Window.mesh.write(me + "x", Window.mouse.getX());
            Window.mesh.write(me + "y", Window.mouse.getY());
            
            keshavx = Window.mesh.read("keshavx");
            keshavy = Window.mesh.read("keshavy");
            
            andrewx = Window.mesh.read("andrewx");
            andrewy = Window.mesh.read("andrewy");
            
            alexx = Window.mesh.read("alexx");
            alexy = Window.mesh.read("alexy");
            
            andrewx = Window.mesh.read("andrewx");
            andrewy = Window.mesh.read("andrewy");
            
            joshx = Window.mesh.read("joshx");
            joshy = Window.mesh.read("joshy");
            
            aryanx = Window.mesh.read("aryanx");
            aryany = Window.mesh.read("aryany");
            
            jeffreyx = Window.mesh.read("jeffreyx");
            jeffreyy = Window.mesh.read("jeffreyy");
            
            nikhilx = Window.mesh.read("nikhilx");
            nikhily = Window.mesh.read("nikhily");
            
            anikax = Window.mesh.read("anikax");
            anikay = Window.mesh.read("anikay");
            
            ishirx = Window.mesh.read("ishirx");
            ishiry = Window.mesh.read("ishiry");
            
            nirekx = Window.mesh.read("nirekx");
            nireky = Window.mesh.read("nireky");
            
            
            // Create a circle where the mouse is
            Window.out.color("orange");
            Window.out.circle(keshavx, keshavy, 10);
            
            Window.out.color("purple");
            Window.out.circle(alexx, alexy, 10);
            
            Window.out.color("pink");
            Window.out.circle(andrewx, andrewy, 10);
            
            Window.out.color("lime");
            Window.out.circle(joshx, joshy, 10);
            
            Window.out.color("yellow");
            Window.out.circle(aryanx, aryany, 10);
            
            Window.out.color("blue");
            Window.out.circle(jeffreyx, jeffreyy, 10);
            
            Window.out.color("red");
            Window.out.circle(nikhilx, nikhily, 10);
            
            Window.out.color("light blue");
            Window.out.circle(anikax, anikay, 10);
            
            Window.out.color("brown");
            Window.out.circle(ishirx, ishiry, 10);
            
            Window.out.color("gray");
            Window.out.circle(nirekx, nireky, 10);
            
            // Wait for a tenth of a second
            Window.sleep(20);
        }
        
    }

}
