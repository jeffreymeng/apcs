import apcs.Window;


public class mutiplayer {

	
	public static void main(String[] args) {
		// http://collab.it
		// connect
		Window.mesh.join("104.236.128.169");
		int x;
		int y;
		int aryanx;
		int aryany;
		int joshx;
		int joshy;
				
		
				
				
		Window.out.background("white");
		Window.out.color("black");
		while (true) {
			y = Window.mouse.getY();
			x = Window.mouse.getX();
			aryanx = Window.mesh.read("aryanx");
			aryany = Window.mesh.read("aryany");
			joshx = Window.mesh.read("joshx");
			joshy = Window.mesh.read("joshy");

			if (Window.mouse.clicked() ) {
				// write
				Window.mesh.write("jeffreyx", x);
				Window.mesh.write("jeffreyy", y);
				Window.out.color("blue");
				Window.out.circle(x, y, 1);
			}
			Window.out.color("yellow");
			Window.out.circle(aryanx, aryany, 1);
			Window.out.color("green");
			Window.out.circle(joshx, joshy, 1);
		}
	}

}
