import apcs.Window;


public class drawing {

	public static void main(String[] args) {
/*
		Window.out.background("light blue");
		//draw tree
		Window.out.rectangle(x, y, width, height)
		// draw ground
		Window.out.color("light green");
		Window.out.circle(250, 1000,560);
		*/
	}

}
