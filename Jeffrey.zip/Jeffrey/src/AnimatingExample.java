import apcs.Window;


public class AnimatingExample {

	public static void main(String[] args) {
		
		
		int x = Window.mouse.getX();
		int y = Window.mouse.getY();
		Window.out.background("white");
		Window.out.color("black");
		while (true) {
			y = Window.mouse.getY();
			x = Window.mouse.getX();
			if (Window.key.released('c')) {
				Window.out.background("white");
			}
			if (Window.mouse.clicked() ) {
				Window.out.circle(x, y, 1);
			}
		}
	}

}
