import apcs.Window;


public class BouncingBall {

	public static void main(String[] args) {
		int width = 500;
		int height = 500;
		Window.size(width, height);
		Window.out.color("red");
		Window.out.background("white");
		int x = 100;
		int y = 100;
		int gravity = 5;
		double speed = 4;
		int size = 25;
		int last = 20;
		while(true) {
			x += (int) speed;
			y += gravity;
			gravity ++;
			if (y >= height - size) {
					y = height - size;
					
					gravity -=  last;
					
					last -= 2;
					
				
			}
			
			Window.out.circle(x, y, size);
			Window.frame();
		}
		
		
	}

}
