import apcs.Window;

public class DrawingServer {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	

		}

	}

}
